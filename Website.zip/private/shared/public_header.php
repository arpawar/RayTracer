<!doctype html>

<html lang="en">
  <head>
       <title>GPU Framework for Point Membership Classification of Geometric Models <?php if(isset($page_title)) { echo '- ' . h($page_title); } ?><?php if(isset($preview) && $preview) { echo ' [PREVIEW]'; } ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" media="all" href="<?php echo url_for('/stylesheets/public.css'); ?>" />
  </head>

  <body>

    <header>
      <h1>
        <a href="<?php echo url_for('/index.php'); ?>">
               <i style="display:block; text-align: center;color: white;line-height:100%;position:relative; top:20px">GPU Framework for Point Membership Classification of Geometric Models
</i>
        </a>
      </h1>
    </header>
