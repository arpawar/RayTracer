<div id="content">
<h1>Background and Motivation</h1>
<p>We implement a 3D parallel solver for Point Membership
Classification in CUDA. This solver is capable to check whether the
randomly selected grid points lie inside or outside the geometry. It has
the applications in the field of simulation such as immersed boundary
analysis methods; in the field of computer graphics such as rendering
photorealistic pictures or adding "fancy" effects in animation. Since
this evaluation involves large computation cost, we implement this
algorithm using GPU framework. All results were computed on a PC
equipped with a 2.66 GHz Intel X5500 CPU and NVIDIA GeForce GTX 1080
Ti. </p>

<h2>About Point Membership Classification (PMC)</h2>

<p> PMC is used to define the representations for sets in
computational geometry that determines whether a point is inside a
geometry. The standard method for deciding if a point is in the
interior is to create a ray starting at the point and aiming in some
selected direction, and then to count the number of crossing
intersections with the boundary representations of the geometry.  </p>

<h2>About Graphics Processing Unit (GPU) Framework</h2>

<p>GPU is a chip processor primarily used to manage and boost the
  performance of video and graphics. Nowadays, GPU has become an important part of High-performance computing platforms. They are being used to accelerate computational workloads. Compared to CPU,
  GPU is optimized for taking a huge amount of data and performing the same operation over and over very quickly. Our parallel implementation demonstrates a hundred times faster speed. We use
  it to create a real-time point membership classification </p>

<h2>About Ray Tracing</h2>

<p>Ray tracing is a rendering technique in computer graphics which
  simulating the effect of light. The technique is capable of producing a very high degree of visual pictures or animation. Here we use ray tracing to determine whether a point is inside a
  geometry.  Each ray will be used to create an intersection with some subset of the geometry. That intersection information will be
  combined to check the final result.</p>

</div>
