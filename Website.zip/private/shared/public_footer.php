  <footer>
    <p>Copyright <?php echo date('Y'); ?>, Raytracer </p>
  </footer>
        <p>This is Raytracer program created by Aishwarya Pawar (arpawar@andrew.cmu.edu), Angran Li (angranl@andrew.cmu.edu), Yuxuan Yu (yuxuany1@andrew.cmu.edu).</p>
  </body>
</html>

<?php
  db_disconnect($db);
?>
