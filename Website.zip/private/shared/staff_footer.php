<footer>
&copy; <?php echo date('Y'); ?> GPU Framework for Point Membership Classification of Geometric Models
</footer>

</body>
</html>

<?php
  db_disconnect($db);
?>
